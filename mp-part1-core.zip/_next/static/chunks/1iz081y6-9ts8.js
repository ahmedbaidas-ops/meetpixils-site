(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,84082,e=>{"use strict";var i=e.i(43476),n=e.i(25448),t=e.i(6999),a=e.i(5657);let o=[{en:["What the judges actually looked for","The Spring scorecard, line by line, with the entries that scored highest."],ar:["شو دوّرت عليه اللجنة فعلاً","معايير الربيع سطر سطر، مع المشاركات الأعلى."],tag:["4 min · EN","٤ دق · EN"]},{en:["Ninety designers, one rooftop","Meetup 03 recap — zero slides, one long argument about Figma."],ar:["تسعين مصمم وسطح واحد","ملخص اللقاء ٠٣ — بدون شرائح، ونقاش طويل عن Figma."],tag:["3 min · AR","٣ دق · AR"]}];e.s(["default",0,function(){let{ar:e}=(0,n.useLang)();return(0,i.jsxs)("div",{children:[(0,i.jsx)(a.PxStyles,{tint:t.ORANGE}),(0,i.jsx)(a.SectionHero,{tint:"#310622",fg:t.CREAM,ar:e,kicker:e?"المجتمع":"Community",title:e?"قصص":"Stories",dek:e?"ملخصات، مقابلات فائزين، وأخبار الموسم.":"Recaps, winner interviews, and season news."}),(0,i.jsxs)(a.Wrap,{style:{padding:"clamp(46px,8vh,80px) clamp(20px,5vw,64px) clamp(70px,11vh,120px)",maxWidth:880},children:[o.map((t,a)=>(0,i.jsxs)("a",{href:"#",onClick:e=>e.preventDefault(),className:"px-row",children:[(0,i.jsxs)("div",{style:{flex:1},children:[(0,i.jsx)("strong",{style:{display:"block",fontSize:18,fontWeight:700},children:(e?t.ar:t.en)[0]}),(0,i.jsx)("span",{style:{fontSize:13.5,color:"rgba(255,254,236,.62)"},children:(e?t.ar:t.en)[1]})]}),(0,i.jsx)("span",{style:{...n.mono,opacity:.5},children:e?t.tag[1]:t.tag[0]}),(0,i.jsx)("span",{className:"arw","aria-hidden":"true",children:"→"})]},a)),(0,i.jsx)("p",{style:{...n.mono,marginTop:20,opacity:.5},children:e?"القصص بتنشر بلغتها — مش كلها مترجمة.":"Stories publish in their own language — not everything is translated."})]})]})}])},5657,e=>{"use strict";var i=e.i(43476),n=e.i(25448),t=e.i(6999);e.s(["Field",0,function({label:e,children:n}){return(0,i.jsxs)("label",{style:{display:"flex",flexDirection:"column",gap:7,fontSize:13,fontWeight:600},children:[e,n]})},"PxStyles",0,function({tint:e="#EF5229"}){return(0,i.jsx)("style",{children:`
      .px-card { position: relative; display: flex; flex-direction: column; gap: 12px;
        padding: 24px 26px; text-decoration: none; color: #FFFEEC;
        background: rgba(255,254,236,.03); box-shadow: inset 0 0 0 1px rgba(255,254,236,.12);
        clip-path: polygon(16px 0,100% 0,100% calc(100% - 16px),calc(100% - 16px) 100%,0 100%,0 16px);
        transition: transform .45s cubic-bezier(.16,1,.3,1), box-shadow .45s }
      .px-card:hover { transform: translateY(-5px); box-shadow: inset 0 0 0 1px var(--tint, ${e}) }
      .px-card:focus-visible { outline: 2px solid var(--tint, ${e}); outline-offset: 3px }
      .px-row { display: flex; align-items: center; gap: 18px; padding: 20px 4px;
        border-bottom: 1px solid rgba(255,254,236,.1); text-decoration: none; color: #FFFEEC;
        transition: padding-inline-start .3s cubic-bezier(.16,1,.3,1), background .3s }
      .px-row:hover { padding-inline-start: 16px; background: rgba(255,254,236,.04) }
      .px-row:focus-visible { outline: 2px solid ${e}; outline-offset: -2px }
      .px-input { transition: border-color .2s, background .2s, box-shadow .2s }
      .px-input:hover { border-color: rgba(255,254,236,.4) }
      .px-input:focus { border-color: ${e}; box-shadow: 0 0 0 3px color-mix(in srgb, ${e} 25%, transparent); background: rgba(255,254,236,.08) }
      .px-float { animation: pxfloat 7s ease-in-out infinite }
      @keyframes pxfloat { 0%,100% { transform: translateY(0) rotate(-1.5deg) } 50% { transform: translateY(-14px) rotate(1.5deg) } }
      @media (prefers-reduced-motion: reduce) {
        .px-card, .px-row, .px-input { transition: none }
        .px-card:hover { transform: none }
        .px-float { animation: none }
      }
    `})},"SectionHero",0,function({tint:e,fg:a=t.PLUM,accent:o="#EF5229",kicker:r,title:p,dek:s,ar:l=!1,children:x}){return(0,i.jsxs)("section",{className:"px-hero",style:{position:"relative",overflow:"hidden",background:e,color:a,paddingTop:92},children:[(0,i.jsx)("div",{"aria-hidden":"true",className:"px-orn",children:[[52,34,60,1,0],[26,108,126,.8,90],[18,34,134,.55,180],[32,130,42,.9,45],[14,88,88,.45,240],[22,168,96,.65,135]].map(([e,n,t,a,r],p)=>(0,i.jsx)("span",{style:{position:"absolute",insetInlineEnd:n,top:t,width:e,height:e,background:o,opacity:0,clipPath:`polygon(${e/4}px 0,100% 0,100% calc(100% - ${e/4}px),calc(100% - ${e/4}px) 100%,0 100%,0 ${e/4}px)`,animation:`px-pop 560ms cubic-bezier(.16,1,.3,1) ${r}ms both`,"--op":a}},p))}),(0,i.jsxs)("div",{style:{maxWidth:1480,margin:"0 auto",padding:"0 clamp(20px,5vw,64px) clamp(44px,7vh,84px)",position:"relative",zIndex:2},children:[(0,i.jsxs)("div",{className:"px-h-a",style:{display:"flex",alignItems:"center",gap:12,marginBottom:10},children:[(0,i.jsx)("span",{"aria-hidden":"true",style:{width:10,height:10,background:o,flex:"0 0 auto",clipPath:"polygon(3px 0,100% 0,100% calc(100% - 3px),calc(100% - 3px) 100%,0 100%,0 3px)"}}),(0,i.jsx)("span",{style:{...n.mono,opacity:.68},children:r})]}),(0,i.jsx)("h1",{className:"px-h-b",style:{margin:0,maxWidth:"15ch",fontSize:"clamp(40px,7vw,92px)",fontWeight:800,letterSpacing:l?0:"-.045em",lineHeight:l?1.3:.98,textWrap:"balance"},children:p}),s&&(0,i.jsx)("p",{className:"px-h-c",style:{margin:"18px 0 0",maxWidth:"46ch",fontSize:"clamp(15px,1.7vw,18px)",lineHeight:l?1.9:1.55,opacity:.74},children:s}),x]}),(0,i.jsx)("div",{"aria-hidden":"true",style:{position:"absolute",insetInline:0,bottom:0,height:6,opacity:.4,background:`repeating-linear-gradient(90deg, ${o} 0 16px, transparent 16px 40px)`}}),(0,i.jsx)("style",{children:`
        @keyframes px-pop { from { opacity: 0; transform: translateY(10px) scale(.7) } to { opacity: var(--op); transform: none } }
        @keyframes px-rise { from { opacity: 0; transform: translateY(14px) } to { opacity: 1; transform: none } }
        .px-h-a { animation: px-rise 560ms cubic-bezier(.16,1,.3,1) both }
        .px-h-b { animation: px-rise 620ms cubic-bezier(.16,1,.3,1) 70ms both }
        .px-h-c { animation: px-rise 680ms cubic-bezier(.16,1,.3,1) 140ms both }
        .px-orn { position: absolute; top: 92px; inset-inline-end: clamp(16px,4vw,60px); width: 210px; height: 200px; z-index: 1 }
        @media (max-width: 760px) { .px-orn { display: none } }
        @media (prefers-reduced-motion: reduce) {
          .px-h-a, .px-h-b, .px-h-c { animation: none }
          .px-orn span { animation: none; opacity: var(--op) }
        }
      `})]})},"Wrap",0,({children:e,style:n})=>(0,i.jsx)("div",{style:{maxWidth:1480,margin:"0 auto",padding:"0 clamp(20px,5vw,64px)",...n},children:e}),"inputStyle",0,{fontFamily:"inherit",fontSize:14,minHeight:46,padding:"12px 14px",background:"rgba(255,254,236,.05)",color:"#FFFEEC",border:"1px solid rgba(255,254,236,.22)",borderRadius:0,outline:"none"}])}]);