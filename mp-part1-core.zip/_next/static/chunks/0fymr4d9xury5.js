(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,11772,e=>{"use strict";var t=e.i(43476),n=e.i(71645),i=e.i(95885),r=e.i(83572),o=e.i(25448),a=e.i(66059);let s="#EF5229",l="#2EBEEF",c="#310622",p="#0F010A",d=(e=14)=>({borderRadius:0,clipPath:`polygon(${e}px 0, 100% 0, 100% calc(100% - ${e}px), calc(100% - ${e}px) 100%, 0 100%, 0 ${e}px)`}),x={fontFamily:"var(--font-mono)",fontSize:11,letterSpacing:".1em",textTransform:"uppercase"},g={maxWidth:1480,margin:"0 auto",padding:"0 clamp(20px,5vw,64px)"},h={type:["Event","Competition","Program"],discipline:["UX/UI","UX Research","Branding","Graphic","Motion & 3D","All"],format:["In person","Online","Hybrid"],city:["Amman","Online"]},m=["٠","١","٢","٣","٤","٥","٦","٧","٨","٩"],u={type:"النوع",discipline:"التخصص",format:"الصيغة",city:"المكان",Event:"فعالية",Competition:"منافسة",Program:"برنامج","UX/UI":"UX/UI","UX Research":"بحث المستخدم",Branding:"براندنج",Graphic:"جرافيك","Motion & 3D":"موشن و٣د",All:"الكل","In person":"حضوري",Online:"أونلاين",Hybrid:"هجين",Amman:"عمّان"},f={"closing-soon":0,open:1,upcoming:2,"results-out":3,closed:4};e.s(["default",0,function(){let{ar:e}=(0,o.useLang)(),[b]=(0,a.useStore)(),[w,y]=(0,n.useState)({type:[],discipline:[],format:[],city:[]}),[v,j]=(0,n.useState)("bento"),[k,C]=(0,n.useState)(()=>Date.now()),z=(0,n.useRef)(null);(0,n.useEffect)(()=>{let e=window.setInterval(()=>C(Date.now()),1e3);return()=>window.clearInterval(e)},[]),(0,n.useEffect)(()=>{let e=z.current;if(!e)return;let t=t=>{let n=e.getBoundingClientRect();e.style.setProperty("--mx",`${(t.clientX-n.left)/n.width*100}%`),e.style.setProperty("--my",`${(t.clientY-n.top)/n.height*100}%`)};return e.addEventListener("pointermove",t),()=>e.removeEventListener("pointermove",t)},[]);let E=()=>y({type:[],discipline:[],format:[],city:[]}),F=Object.values(w).reduce((e,t)=>e+t.length,0),N=(0,n.useMemo)(()=>b.objects.filter(e=>(!w.type.length||w.type.includes(e.type))&&(!w.discipline.length||w.discipline.includes(e.discipline))&&(!w.format.length||w.format.includes(e.format))&&(!w.city.length||w.city.includes(e.city))).sort((e,t)=>f[e.status]-f[t.status]),[w,b]),S=N.filter(e=>"closing-soon"===e.status),$=e=>e?Math.max(0,Math.ceil((new Date(e).getTime()-k)/864e5)):null,W=t=>e?String(t).replace(/\d/g,e=>m[+e]):String(t),I=t=>{let n=$(t.due);if("closing-soon"===t.status)return e?`يغلق خلال ${W(n??0)} أيام`:`Closes in ${n??0} days`;let i={"closing-soon":["",""],open:["Open","مفتوح"],upcoming:["Upcoming","قريباً"],"results-out":["Results out","النتائج ظهرت"],closed:["Closed","انتهى"]};return e?i[t.status][1]:i[t.status][0]};return(0,t.jsxs)("div",{dir:e?"rtl":"ltr",lang:e?"ar":"en",style:{background:p,color:"#FFFEEC",minHeight:"100vh",fontFamily:e?"var(--font-arabic)":"var(--font-sans)"},children:[(0,t.jsxs)("header",{ref:z,className:"wo-head",style:{position:"relative",overflow:"hidden",background:l,color:c,paddingTop:92},children:[(0,t.jsx)("div",{"aria-hidden":"true",className:"wo-grid"}),(0,t.jsx)("div",{"aria-hidden":"true",className:"wo-spot"}),(0,t.jsxs)("div",{style:{...g,position:"relative",zIndex:2,paddingBottom:"clamp(44px,7vh,84px)"},children:[(0,t.jsx)("a",{href:"/",style:{...x,color:c,opacity:.6,textDecoration:"none",display:"inline-block",marginBottom:22},children:e?"← ميت بيكسلز":"← MeetPixils"}),(0,t.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:14,marginBottom:10},children:[(0,t.jsx)(i.MeetMark,{size:34,color:c}),(0,t.jsx)("span",{style:{...x,opacity:.68},children:e?"ميت إكسبيرينس":"MeetExperience"})]}),(0,t.jsx)("h1",{style:{margin:0,maxWidth:"14ch",fontSize:"clamp(44px,8vw,104px)",fontWeight:800,letterSpacing:e?0:"-.045em",lineHeight:e?1.28:.96},children:e?"شو في قريب؟":"What's on"}),(0,t.jsx)("p",{style:{margin:"20px 0 0",maxWidth:"44ch",fontSize:"clamp(15px,1.8vw,19px)",lineHeight:e?1.9:1.55,color:"rgba(49,6,34,.72)"},children:e?"كل اللي جاي — تحديات، ورشات، لقاءات، وليلة النهائي. فلتر حسب اللي بناسبك.":"Everything coming up — battles, workshops, meetups, and the season finale. Filter it down to what fits."})]})]}),S.length>0&&(0,t.jsx)("div",{style:{background:s,color:p},children:(0,t.jsxs)("div",{style:{...g,display:"flex",flexWrap:"wrap",alignItems:"center",gap:16,padding:"14px clamp(20px,5vw,64px)"},children:[(0,t.jsx)("span",{style:{...x,fontWeight:700},children:e?"يغلق قريباً":"Closing soon"}),S.map(n=>(0,t.jsxs)("a",{href:`/compete/${n.id}`,style:{...x,color:p,textDecoration:"none",display:"inline-flex",gap:8},children:[(0,t.jsxs)("span",{style:{fontWeight:700},children:[W($(n.due)??0),e?" يوم":"d"]}),(0,t.jsx)("span",{style:{opacity:.78},children:(e?n.ar:n.en).t.slice(0,34)})]},n.id))]})}),(0,t.jsx)("div",{className:"wo-bar",style:{position:"sticky",top:0,zIndex:40},children:(0,t.jsxs)("div",{style:{...g,display:"flex",flexWrap:"wrap",alignItems:"center",gap:10,padding:"12px clamp(20px,5vw,64px)"},children:[Object.keys(h).map(n=>(0,t.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:6,flexWrap:"wrap"},children:[(0,t.jsx)("span",{style:{...x,opacity:.45},children:e?u[n]:n}),h[n].map(i=>{let r=w[n].includes(i);return(0,t.jsx)("button",{type:"button",onClick:()=>y(e=>({...e,[n]:e[n].includes(i)?e[n].filter(e=>e!==i):[...e[n],i]})),"aria-pressed":r,className:"wo-chip",style:r?{background:l,color:p,borderColor:l}:void 0,children:e?u[i]??i:i},i)})]},n)),(0,t.jsxs)("div",{style:{marginInlineStart:"auto",display:"flex",alignItems:"center",gap:10},children:[F>0&&(0,t.jsx)("button",{type:"button",onClick:E,className:"wo-chip",style:{borderColor:s,color:s},children:e?`مسح (${W(F)})`:`Clear (${F})`}),(0,t.jsxs)("div",{className:"wo-seg",children:[(0,t.jsx)("button",{type:"button","aria-pressed":"bento"===v,onClick:()=>j("bento"),children:e?"شبكة":"Grid"}),(0,t.jsx)("button",{type:"button","aria-pressed":"list"===v,onClick:()=>j("list"),children:e?"قائمة":"List"})]}),(0,t.jsxs)("span",{"aria-live":"polite",style:{...x,opacity:.6,fontVariantNumeric:"tabular-nums"},children:[W(N.length)," ",e?"نتيجة":"results"]})]})]})}),(0,t.jsx)("section",{style:{padding:"clamp(34px,6vh,64px) 0 clamp(70px,12vh,120px)"},children:(0,t.jsx)("div",{style:g,children:0===N.length?(0,t.jsxs)("div",{style:{border:"1px dashed rgba(255,254,236,.24)",padding:"44px 28px",textAlign:"center",...d(16)},children:[(0,t.jsx)("strong",{style:{display:"block",fontSize:20,marginBottom:10},children:e?"ما في إشي بهالفلاتر":"Nothing matches those filters"}),(0,t.jsx)("p",{style:{margin:"0 auto 20px",maxWidth:"44ch",color:"rgba(255,254,236,.7)",fontSize:14},children:e?"بس في ٩ أشياء جاية هالموسم — شيل فلتر أو اثنين.":"There are still 9 things coming this season — try dropping a filter."}),(0,t.jsx)("button",{onClick:E,className:"wo-cta",style:{background:l,color:p},children:e?"امسح الفلاتر":"Clear filters"})]}):"list"===v?(0,t.jsx)("ul",{style:{listStyle:"none",margin:0,padding:0},children:N.map(n=>{let i=e?n.ar:n.en;return(0,t.jsx)("li",{children:(0,t.jsxs)("a",{href:(0,a.objHref)(n),className:"wo-row",children:[(0,t.jsx)("span",{style:{...x,color:n.tint,minWidth:96},children:i.when}),(0,t.jsx)("strong",{style:{flex:1,fontSize:17,fontWeight:650},children:i.t}),(0,t.jsx)("span",{style:{...x,opacity:.55},children:e?u[n.format]:n.format}),(0,t.jsx)("span",{style:{...x,color:"closing-soon"===n.status?s:"rgba(255,254,236,.55)"},children:I(n)}),(0,t.jsx)("span",{className:"arw","aria-hidden":"true",children:"→"})]})},n.id)})}):(0,t.jsx)("div",{style:{display:"grid",gridTemplateColumns:"repeat(12,1fr)",gap:16},children:N.map((n,i)=>{let o=e?n.ar:n.en,l="closing-soon"===n.status;return(0,t.jsx)(r.Reveal,{delay:Math.min(55*i,330),className:"wo-cell",style:{gridColumn:"closing-soon"===n.status?"span 12":"open"===n.status&&i<3?"span 6":"span 4"},children:(0,t.jsxs)("a",{href:(0,a.objHref)(n),className:"wo-card",style:{"--tint":n.tint,minHeight:l?300:240,...d(16)},children:[(0,t.jsx)("span",{"aria-hidden":"true",className:"wo-wash"}),(0,t.jsxs)("div",{className:"wo-cardtop",children:[(0,t.jsxs)("span",{className:"wo-status",style:"closing-soon"===n.status?{background:s,color:p}:{border:`1px solid ${n.tint}`,color:n.tint},children:["closing-soon"===n.status&&(0,t.jsx)("span",{className:"wo-dot"}),I(n)]}),(0,t.jsx)("span",{style:{...x,opacity:.5},children:n.arm})]}),(0,t.jsx)("strong",{style:{fontSize:l?"clamp(24px,3.4vw,40px)":19,fontWeight:750,letterSpacing:e?0:"-.025em",lineHeight:e?1.45:1.14,maxWidth:"20ch"},children:o.t}),(0,t.jsx)("p",{style:{margin:0,fontSize:13.5,color:"rgba(255,254,236,.66)",maxWidth:"46ch",lineHeight:e?1.8:1.5},children:o.d}),(0,t.jsx)("div",{className:"wo-meta",children:[o.when,e?u[n.format]:n.format,e?u[n.city]??n.city:n.city,n.level].map((e,i)=>(0,t.jsx)("span",{className:"wo-tag",children:e},`${n.id}-m${i}`))}),(0,t.jsxs)("span",{className:"wo-cta",style:{background:n.tint,color:p},children:[o.cta,(0,t.jsx)("span",{className:"arw","aria-hidden":"true",children:"→"})]})]})},n.id)})})})}),(0,t.jsx)("section",{style:{background:c,padding:"clamp(50px,9vh,90px) 0"},children:(0,t.jsx)("div",{style:{...g,display:"grid",gap:16,gridTemplateColumns:"repeat(auto-fit,minmax(260px,1fr))"},children:[{href:"/compete",tint:"#CCA4FD",en:["Want to be in it, not at it?","See how battles work"],ar:["بدك تشارك مش بس تحضر؟","كيف بتشتغل الـ Battles"]},{href:"/learn",tint:"#C3B8FB",en:["Building a skill, not a night out?","Explore the Academy"],ar:["بدك تبني مهارة؟","اكتشف الأكاديمية"]}].map(n=>(0,t.jsxs)("a",{href:n.href,className:"wo-cross",style:{"--tint":n.tint,...d(14)},children:[(0,t.jsx)("strong",{style:{fontSize:19,fontWeight:700,letterSpacing:e?0:"-.02em"},children:(e?n.ar:n.en)[0]}),(0,t.jsxs)("span",{style:{...x,color:n.tint},children:[(e?n.ar:n.en)[1],(0,t.jsx)("span",{className:"arw","aria-hidden":"true",children:"→"})]})]},n.href))})}),(0,t.jsx)("style",{children:`
        .wo-head { --mx: 70%; --my: 30%; }
        .wo-grid {
          position: absolute; inset: 0;
          background-image: linear-gradient(rgba(49,6,34,.10) 1px, transparent 1px),
                            linear-gradient(90deg, rgba(49,6,34,.10) 1px, transparent 1px);
          background-size: 46px 46px;
          mask-image: radial-gradient(120% 100% at 50% 0%, #000 40%, transparent 100%);
        }
        .wo-spot {
          position: absolute; inset: 0; pointer-events: none;
          background: radial-gradient(340px circle at var(--mx) var(--my), rgba(255,254,236,.42), transparent 60%);
          transition: opacity .3s;
        }
        .wo-lang:hover { filter: brightness(1.15) }
        .wo-bar {
          background: rgba(15,1,10,.72);
          backdrop-filter: blur(28px) saturate(1.7) brightness(.7);
          -webkit-backdrop-filter: blur(28px) saturate(1.7) brightness(.7);
        }
        .wo-chip {
          font-family: var(--font-mono); font-size: 11px; letter-spacing: .06em;
          min-height: 32px; padding: 7px 12px; cursor: pointer;
          background: transparent; color: rgba(255,254,236,.72);
          border: 1px solid rgba(255,254,236,.22); border-radius: 0;
          transition: background .2s, color .2s, border-color .2s, transform .15s;
        }
        .wo-chip:hover { color: #FFFEEC; border-color: rgba(255,254,236,.5) }
        .wo-chip:active { transform: translateY(1px) }
        .wo-chip:focus-visible { outline: 2px solid ${l}; outline-offset: 2px }
        .wo-seg { display: inline-flex; border: 1px solid rgba(255,254,236,.22) }
        .wo-seg button {
          font-family: var(--font-mono); font-size: 11px; letter-spacing: .06em; text-transform: uppercase;
          min-height: 32px; padding: 7px 14px; background: none; border: 0; cursor: pointer; color: rgba(255,254,236,.6);
        }
        .wo-seg button[aria-pressed="true"] { background: rgba(255,254,236,.12); color: #FFFEEC }
        .wo-seg button:focus-visible { outline: 2px solid ${l}; outline-offset: -2px }
        .wo-card {
          position: relative; overflow: hidden; height: 100%;
          display: flex; flex-direction: column; gap: 12; gap: 12px;
          padding: 26px 28px; text-decoration: none; color: #FFFEEC;
          background: rgba(255,254,236,.03);
          box-shadow: inset 0 0 0 1px rgba(255,254,236,.12);
          transition: transform .45s cubic-bezier(.16,1,.3,1), box-shadow .45s cubic-bezier(.16,1,.3,1);
        }
        .wo-card:hover { transform: translateY(-6px); box-shadow: inset 0 0 0 1px var(--tint) }
        .wo-card:focus-visible { outline: 2px solid var(--tint); outline-offset: 3px }
        .wo-wash {
          position: absolute; inset: 0; pointer-events: none; opacity: 0;
          background: radial-gradient(120% 90% at 50% 120%, color-mix(in srgb, var(--tint) 26%, transparent), transparent 70%);
          transition: opacity .45s cubic-bezier(.16,1,.3,1);
        }
        .wo-card:hover .wo-wash { opacity: 1 }
        .wo-card > * { position: relative }
        .wo-cardtop { display: flex; align-items: center; justify-content: space-between; gap: 10px }
        .wo-status {
          display: inline-flex; align-items: center; gap: 7px;
          font-family: var(--font-mono); font-size: 10px; font-weight: 700; letter-spacing: .1em; text-transform: uppercase;
          padding: 6px 12px; white-space: nowrap;
        }
        .wo-dot { width: 6px; height: 6px; border-radius: 999px; background: currentColor; animation: wopulse 1.6s infinite }
        @keyframes wopulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:.35;transform:scale(.7)} }
        .wo-meta { display: flex; flex-wrap: wrap; gap: 8px; margin-top: auto }
        .wo-tag {
          font-family: var(--font-mono); font-size: 10px; letter-spacing: .08em; text-transform: uppercase;
          padding: 5px 10px; border: 1px solid rgba(255,254,236,.18); color: rgba(255,254,236,.66); white-space: nowrap;
        }
        .wo-cta {
          align-self: flex-start; font-family: var(--font-mono); font-size: 12px; font-weight: 700;
          padding: 12px 20px; cursor: pointer; border: 0;
          clip-path: polygon(10px 0,100% 0,100% calc(100% - 10px),calc(100% - 10px) 100%,0 100%,0 10px);
          transition: transform .2s cubic-bezier(.16,1,.3,1);
        }
        .wo-card:hover .wo-cta { transform: translateX(3px) }
        [dir="rtl"] .wo-card:hover .wo-cta { transform: translateX(-3px) }
        .arw { display: inline-block; margin-inline-start: 8px; transition: transform .3s cubic-bezier(.16,1,.3,1) }
        .wo-row:hover .arw, .wo-cross:hover .arw { transform: translateX(5px) }
        [dir="rtl"] .wo-row:hover .arw, [dir="rtl"] .wo-cross:hover .arw { transform: translateX(-5px) }
        .wo-row {
          display: flex; align-items: center; gap: 18px; padding: 20px 4px;
          border-bottom: 1px solid rgba(255,254,236,.1); text-decoration: none; color: #FFFEEC;
          transition: padding-inline-start .3s cubic-bezier(.16,1,.3,1), background .3s;
        }
        .wo-row:hover { padding-inline-start: 16px; background: rgba(255,254,236,.04) }
        .wo-row:focus-visible { outline: 2px solid ${l}; outline-offset: -2px }
        .wo-cross {
          display: flex; flex-direction: column; justify-content: space-between; gap: 20px;
          min-height: 150px; padding: 26px 28px; text-decoration: none; color: #FFFEEC;
          box-shadow: inset 0 0 0 1px rgba(255,254,236,.14);
          transition: transform .4s cubic-bezier(.16,1,.3,1), box-shadow .4s;
        }
        .wo-cross:hover { transform: translateY(-4px); box-shadow: inset 0 0 0 1px var(--tint) }
        @media (max-width: 900px) { .wo-cell { grid-column: span 12 !important } }
        @media (prefers-reduced-motion: reduce) {
          .wo-card, .wo-cross, .wo-row, .arw, .wo-cta, .wo-wash { transition: none }
          .wo-card:hover, .wo-cross:hover { transform: none }
          .wo-dot { animation: none }
          .wo-spot { display: none }
        }
      `})]})}])},83572,e=>{"use strict";var t=e.i(43476),n=e.i(71645);e.s(["Reveal",0,function({children:e,delay:i=0,y:r=20,duration:o=700,threshold:a=.15,className:s,style:l}){let c=n.useRef(null),[p,d]=n.useState(!1);return n.useEffect(()=>{let e=c.current;if(!e)return;if(window.matchMedia("(prefers-reduced-motion: reduce)").matches)return void d(!0);let t=new IntersectionObserver(e=>{e.forEach(e=>{(e.isIntersecting||e.boundingClientRect.top<0)&&(d(!0),t.disconnect())})},{threshold:a,rootMargin:"0px 0px -6% 0px"});return t.observe(e),()=>t.disconnect()},[a]),(0,t.jsx)("div",{ref:c,className:s,style:{opacity:+!!p,transform:p?"none":`translateY(${r}px)`,transition:`opacity ${o}ms cubic-bezier(.16,1,.3,1) ${i}ms, transform ${o}ms cubic-bezier(.16,1,.3,1) ${i}ms`,willChange:p?"auto":"opacity, transform",...l},children:e})}])}]);