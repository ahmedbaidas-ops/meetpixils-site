(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,60078,e=>{"use strict";var t=e.i(43476),i=e.i(25448),n=e.i(6999),a=e.i(5657),r=e.i(18743),o=e.i(83572);e.s(["default",0,function(){let{ar:e}=(0,i.useLang)();return(0,t.jsxs)("div",{children:[(0,t.jsx)(a.PxStyles,{tint:n.ORANGE}),(0,t.jsx)(a.SectionHero,{tint:"#310622",fg:n.CREAM,ar:e,kicker:e?"ميت بيكسلز":"MeetPixils",title:e?"مين إحنا":"Who we are",dek:e?"فريق من عمّان بيبني موسم الإبداع الأردني — فعالية بفعالية.":"A team in Amman building Jordan's creative season — one event at a time."}),(0,t.jsx)("section",{style:{background:n.CREAM,color:"#310622",padding:"clamp(60px,10vh,110px) 0"},children:(0,t.jsx)(a.Wrap,{children:(0,t.jsx)(r.PixelStatement,{ar:e,faint:"rgba(49,6,34,.16)",full:"#310622",text:e?"الموهبة موجودة. اللي كان ناقص المسرح — عم نبنيه.":"The talent was always here. The stage wasn't — so we're building it."})})}),(0,t.jsx)(a.Wrap,{style:{padding:"clamp(46px,8vh,80px) clamp(20px,5vw,64px) clamp(70px,11vh,120px)"},children:[{href:"/about/ecosystem",en:"The five arms",ar:"الأذرع الخمسة"},{href:"/about/partners",en:"Partners & sponsors",ar:"الشركاء والرعاة"},{href:"/about/sponsor",en:"Sponsor an event",ar:"ارعَ فعالية"},{href:"/about/contact",en:"Contact",ar:"تواصل معنا"}].map(i=>(0,t.jsx)(o.Reveal,{children:(0,t.jsxs)("a",{href:i.href,className:"px-row",children:[(0,t.jsx)("strong",{style:{flex:1,fontSize:17},children:e?i.ar:i.en}),(0,t.jsx)("span",{className:"arw","aria-hidden":"true",children:"→"})]})},i.href))})]})}])},5657,e=>{"use strict";var t=e.i(43476),i=e.i(25448),n=e.i(6999);e.s(["Field",0,function({label:e,children:i}){return(0,t.jsxs)("label",{style:{display:"flex",flexDirection:"column",gap:7,fontSize:13,fontWeight:600},children:[e,i]})},"PxStyles",0,function({tint:e="#EF5229"}){return(0,t.jsx)("style",{children:`
      .px-card { position: relative; display: flex; flex-direction: column; gap: 12px;
        padding: 24px 26px; text-decoration: none; color: #FFFEEC;
        background: rgba(255,254,236,.03); box-shadow: inset 0 0 0 1px rgba(255,254,236,.12);
        clip-path: polygon(16px 0,100% 0,100% calc(100% - 16px),calc(100% - 16px) 100%,0 100%,0 16px);
        transition: transform .45s cubic-bezier(.16,1,.3,1), box-shadow .45s }
      .px-card:hover { transform: translateY(-5px); box-shadow: inset 0 0 0 1px var(--tint, ${e}) }
      .px-card:focus-visible { outline: 2px solid var(--tint, ${e}); outline-offset: 3px }
      .px-row { display: flex; align-items: center; gap: 18px; padding: 20px 4px;
        border-bottom: 1px solid rgba(255,254,236,.1); text-decoration: none; color: #FFFEEC;
        transition: padding-inline-start .3s cubic-bezier(.16,1,.3,1), background .3s }
      .px-row:hover { padding-inline-start: 16px; background: rgba(255,254,236,.04) }
      .px-row:focus-visible { outline: 2px solid ${e}; outline-offset: -2px }
      .px-input { transition: border-color .2s, background .2s, box-shadow .2s }
      .px-input:hover { border-color: rgba(255,254,236,.4) }
      .px-input:focus { border-color: ${e}; box-shadow: 0 0 0 3px color-mix(in srgb, ${e} 25%, transparent); background: rgba(255,254,236,.08) }
      .px-float { animation: pxfloat 7s ease-in-out infinite }
      @keyframes pxfloat { 0%,100% { transform: translateY(0) rotate(-1.5deg) } 50% { transform: translateY(-14px) rotate(1.5deg) } }
      @media (prefers-reduced-motion: reduce) {
        .px-card, .px-row, .px-input { transition: none }
        .px-card:hover { transform: none }
        .px-float { animation: none }
      }
    `})},"SectionHero",0,function({tint:e,fg:a=n.PLUM,accent:r="#EF5229",kicker:o,title:s,dek:p,ar:c=!1,children:l}){return(0,t.jsxs)("section",{className:"px-hero",style:{position:"relative",overflow:"hidden",background:e,color:a,paddingTop:92},children:[(0,t.jsx)("div",{"aria-hidden":"true",className:"px-orn",children:[[52,34,60,1,0],[26,108,126,.8,90],[18,34,134,.55,180],[32,130,42,.9,45],[14,88,88,.45,240],[22,168,96,.65,135]].map(([e,i,n,a,o],s)=>(0,t.jsx)("span",{style:{position:"absolute",insetInlineEnd:i,top:n,width:e,height:e,background:r,opacity:0,clipPath:`polygon(${e/4}px 0,100% 0,100% calc(100% - ${e/4}px),calc(100% - ${e/4}px) 100%,0 100%,0 ${e/4}px)`,animation:`px-pop 560ms cubic-bezier(.16,1,.3,1) ${o}ms both`,"--op":a}},s))}),(0,t.jsxs)("div",{style:{maxWidth:1480,margin:"0 auto",padding:"0 clamp(20px,5vw,64px) clamp(44px,7vh,84px)",position:"relative",zIndex:2},children:[(0,t.jsxs)("div",{className:"px-h-a",style:{display:"flex",alignItems:"center",gap:12,marginBottom:10},children:[(0,t.jsx)("span",{"aria-hidden":"true",style:{width:10,height:10,background:r,flex:"0 0 auto",clipPath:"polygon(3px 0,100% 0,100% calc(100% - 3px),calc(100% - 3px) 100%,0 100%,0 3px)"}}),(0,t.jsx)("span",{style:{...i.mono,opacity:.68},children:o})]}),(0,t.jsx)("h1",{className:"px-h-b",style:{margin:0,maxWidth:"15ch",fontSize:"clamp(40px,7vw,92px)",fontWeight:800,letterSpacing:c?0:"-.045em",lineHeight:c?1.3:.98,textWrap:"balance"},children:s}),p&&(0,t.jsx)("p",{className:"px-h-c",style:{margin:"18px 0 0",maxWidth:"46ch",fontSize:"clamp(15px,1.7vw,18px)",lineHeight:c?1.9:1.55,opacity:.74},children:p}),l]}),(0,t.jsx)("div",{"aria-hidden":"true",style:{position:"absolute",insetInline:0,bottom:0,height:6,opacity:.4,background:`repeating-linear-gradient(90deg, ${r} 0 16px, transparent 16px 40px)`}}),(0,t.jsx)("style",{children:`
        @keyframes px-pop { from { opacity: 0; transform: translateY(10px) scale(.7) } to { opacity: var(--op); transform: none } }
        @keyframes px-rise { from { opacity: 0; transform: translateY(14px) } to { opacity: 1; transform: none } }
        .px-h-a { animation: px-rise 560ms cubic-bezier(.16,1,.3,1) both }
        .px-h-b { animation: px-rise 620ms cubic-bezier(.16,1,.3,1) 70ms both }
        .px-h-c { animation: px-rise 680ms cubic-bezier(.16,1,.3,1) 140ms both }
        .px-orn { position: absolute; top: 92px; inset-inline-end: clamp(16px,4vw,60px); width: 210px; height: 200px; z-index: 1 }
        @media (max-width: 760px) { .px-orn { display: none } }
        @media (prefers-reduced-motion: reduce) {
          .px-h-a, .px-h-b, .px-h-c { animation: none }
          .px-orn span { animation: none; opacity: var(--op) }
        }
      `})]})},"Wrap",0,({children:e,style:i})=>(0,t.jsx)("div",{style:{maxWidth:1480,margin:"0 auto",padding:"0 clamp(20px,5vw,64px)",...i},children:e}),"inputStyle",0,{fontFamily:"inherit",fontSize:14,minHeight:46,padding:"12px 14px",background:"rgba(255,254,236,.05)",color:"#FFFEEC",border:"1px solid rgba(255,254,236,.22)",borderRadius:0,outline:"none"}])},18743,e=>{"use strict";var t=e.i(43476),i=e.i(71645);e.s(["PixelStatement",0,function({text:e,faint:n="rgba(49,6,34,.18)",full:a="#310622",size:r="clamp(26px,4.2vw,54px)",ar:o=!1,className:s}){let p=i.useRef(null),[c,l]=i.useState(!1),[x,d]=i.useState(0),m=i.useMemo(()=>e.split(/\s+/),[e]);return i.useEffect(()=>{let e=p.current;if(!e)return;if(window.matchMedia("(prefers-reduced-motion: reduce)").matches){l(!0),d(m.length);return}let t=new IntersectionObserver(e=>{e.forEach(e=>{(e.isIntersecting||e.boundingClientRect.top<0)&&(l(!0),t.disconnect())})},{threshold:.2});t.observe(e);let i=0,n=()=>{i||(i=requestAnimationFrame(()=>{i=0;let t=e.getBoundingClientRect(),n=Math.max(1,.55*window.innerHeight);d(Math.round(Math.min(1,Math.max(0,(.82*window.innerHeight-t.top)/n))*m.length))}))};return n(),window.addEventListener("scroll",n,{passive:!0}),()=>{t.disconnect(),window.removeEventListener("scroll",n),i&&cancelAnimationFrame(i)}},[m.length]),(0,t.jsxs)("p",{ref:p,className:s,style:{margin:0,fontSize:r,fontWeight:700,letterSpacing:o?0:"-.035em",lineHeight:o?1.55:1.14,maxWidth:"26ch",textWrap:"balance"},children:[m.map((e,i)=>(0,t.jsxs)("span",{className:c?"pxw in":"pxw",style:{color:i<x?a:n,transitionDelay:c?void 0:`${Math.min(34*i,900)}ms`,animationDelay:`${Math.min(34*i,900)}ms`},children:[e," "]},i)),(0,t.jsx)("style",{children:`
        .pxw {
          display: inline; opacity: 0;
          transition: color .5s cubic-bezier(.16,1,.3,1);
        }
        .pxw.in { animation: pxin .55s steps(5) forwards }
        @keyframes pxin {
          0%   { opacity: 0; -webkit-mask-image: repeating-conic-gradient(#000 0 25%, transparent 0 50%); mask-image: repeating-conic-gradient(#000 0 25%, transparent 0 50%); -webkit-mask-size: 22px 22px; mask-size: 22px 22px }
          35%  { opacity: 1; -webkit-mask-size: 13px 13px; mask-size: 13px 13px }
          70%  { -webkit-mask-size: 6px 6px; mask-size: 6px 6px }
          99%  { -webkit-mask-size: 3px 3px; mask-size: 3px 3px }
          100% { opacity: 1; -webkit-mask-image: none; mask-image: none }
        }
        @media (prefers-reduced-motion: reduce) {
          .pxw { opacity: 1; transition: none }
          .pxw.in { animation: none }
        }
      `})]})}])},83572,e=>{"use strict";var t=e.i(43476),i=e.i(71645);e.s(["Reveal",0,function({children:e,delay:n=0,y:a=20,duration:r=700,threshold:o=.15,className:s,style:p}){let c=i.useRef(null),[l,x]=i.useState(!1);return i.useEffect(()=>{let e=c.current;if(!e)return;if(window.matchMedia("(prefers-reduced-motion: reduce)").matches)return void x(!0);let t=new IntersectionObserver(e=>{e.forEach(e=>{(e.isIntersecting||e.boundingClientRect.top<0)&&(x(!0),t.disconnect())})},{threshold:o,rootMargin:"0px 0px -6% 0px"});return t.observe(e),()=>t.disconnect()},[o]),(0,t.jsx)("div",{ref:c,className:s,style:{opacity:+!!l,transform:l?"none":`translateY(${a}px)`,transition:`opacity ${r}ms cubic-bezier(.16,1,.3,1) ${n}ms, transform ${r}ms cubic-bezier(.16,1,.3,1) ${n}ms`,willChange:l?"auto":"opacity, transform",...p},children:e})}])}]);