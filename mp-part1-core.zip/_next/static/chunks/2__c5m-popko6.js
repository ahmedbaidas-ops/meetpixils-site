(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,50698,e=>{"use strict";var i=e.i(43476),o=e.i(25448),t=e.i(6999),n=e.i(5657);e.s(["default",0,function(){let{ar:e}=(0,o.useLang)();return(0,i.jsxs)("div",{children:[(0,i.jsx)(n.SectionHero,{tint:"#310622",fg:t.CREAM,ar:e,kicker:e?"ملفي":"My profile",title:e?"شهاداتي":"Certificates",dek:e?"كل ورشة أو مسار بتكمله بيطلعلك شهادة هون.":"Every workshop or track you finish lands a certificate here."}),(0,i.jsx)(n.Wrap,{style:{padding:"clamp(40px,7vh,70px) clamp(20px,5vw,64px) clamp(70px,11vh,120px)",maxWidth:760},children:(0,i.jsxs)("div",{style:{border:"1px dashed rgba(255,254,236,.3)",padding:"34px 28px",...(0,o.cut)(16)},children:[(0,i.jsx)("strong",{style:{display:"block",fontSize:19,marginBottom:8},children:e?"ولا شهادة لسا":"None yet"}),(0,i.jsx)("p",{style:{margin:"0 0 14px",fontSize:14,color:"rgba(255,254,236,.68)"},children:e?"أقرب وحدة: ورشة بحث المستخدم — ٤ أيلول.":"Your nearest one: the UX Research workshop — 4 Sep."}),(0,i.jsx)("a",{href:"/whats-on/ux-research-workshop",className:"u-link",style:{...o.mono,color:t.ORANGE,textDecoration:"none"},children:e?"احجز مقعدك ←":"Save a seat →"})]})})]})}])},5657,e=>{"use strict";var i=e.i(43476),o=e.i(25448),t=e.i(6999);e.s(["Field",0,function({label:e,children:o}){return(0,i.jsxs)("label",{style:{display:"flex",flexDirection:"column",gap:7,fontSize:13,fontWeight:600},children:[e,o]})},"PxStyles",0,function({tint:e="#EF5229"}){return(0,i.jsx)("style",{children:`
      .px-card { position: relative; display: flex; flex-direction: column; gap: 12px;
        padding: 24px 26px; text-decoration: none; color: #FFFEEC;
        background: rgba(255,254,236,.03); box-shadow: inset 0 0 0 1px rgba(255,254,236,.12);
        clip-path: polygon(16px 0,100% 0,100% calc(100% - 16px),calc(100% - 16px) 100%,0 100%,0 16px);
        transition: transform .45s cubic-bezier(.16,1,.3,1), box-shadow .45s }
      .px-card:hover { transform: translateY(-5px); box-shadow: inset 0 0 0 1px var(--tint, ${e}) }
      .px-card:focus-visible { outline: 2px solid var(--tint, ${e}); outline-offset: 3px }
      .px-row { display: flex; align-items: center; gap: 18px; padding: 20px 4px;
        border-bottom: 1px solid rgba(255,254,236,.1); text-decoration: none; color: #FFFEEC;
        transition: padding-inline-start .3s cubic-bezier(.16,1,.3,1), background .3s }
      .px-row:hover { padding-inline-start: 16px; background: rgba(255,254,236,.04) }
      .px-row:focus-visible { outline: 2px solid ${e}; outline-offset: -2px }
      .px-input { transition: border-color .2s, background .2s, box-shadow .2s }
      .px-input:hover { border-color: rgba(255,254,236,.4) }
      .px-input:focus { border-color: ${e}; box-shadow: 0 0 0 3px color-mix(in srgb, ${e} 25%, transparent); background: rgba(255,254,236,.08) }
      .px-float { animation: pxfloat 7s ease-in-out infinite }
      @keyframes pxfloat { 0%,100% { transform: translateY(0) rotate(-1.5deg) } 50% { transform: translateY(-14px) rotate(1.5deg) } }
      @media (prefers-reduced-motion: reduce) {
        .px-card, .px-row, .px-input { transition: none }
        .px-card:hover { transform: none }
        .px-float { animation: none }
      }
    `})},"SectionHero",0,function({tint:e,fg:n=t.PLUM,accent:a="#EF5229",kicker:r,title:p,dek:s,ar:x=!1,children:l}){return(0,i.jsxs)("section",{className:"px-hero",style:{position:"relative",overflow:"hidden",background:e,color:n,paddingTop:92},children:[(0,i.jsx)("div",{"aria-hidden":"true",className:"px-orn",children:[[52,34,60,1,0],[26,108,126,.8,90],[18,34,134,.55,180],[32,130,42,.9,45],[14,88,88,.45,240],[22,168,96,.65,135]].map(([e,o,t,n,r],p)=>(0,i.jsx)("span",{style:{position:"absolute",insetInlineEnd:o,top:t,width:e,height:e,background:a,opacity:0,clipPath:`polygon(${e/4}px 0,100% 0,100% calc(100% - ${e/4}px),calc(100% - ${e/4}px) 100%,0 100%,0 ${e/4}px)`,animation:`px-pop 560ms cubic-bezier(.16,1,.3,1) ${r}ms both`,"--op":n}},p))}),(0,i.jsxs)("div",{style:{maxWidth:1480,margin:"0 auto",padding:"0 clamp(20px,5vw,64px) clamp(44px,7vh,84px)",position:"relative",zIndex:2},children:[(0,i.jsxs)("div",{className:"px-h-a",style:{display:"flex",alignItems:"center",gap:12,marginBottom:10},children:[(0,i.jsx)("span",{"aria-hidden":"true",style:{width:10,height:10,background:a,flex:"0 0 auto",clipPath:"polygon(3px 0,100% 0,100% calc(100% - 3px),calc(100% - 3px) 100%,0 100%,0 3px)"}}),(0,i.jsx)("span",{style:{...o.mono,opacity:.68},children:r})]}),(0,i.jsx)("h1",{className:"px-h-b",style:{margin:0,maxWidth:"15ch",fontSize:"clamp(40px,7vw,92px)",fontWeight:800,letterSpacing:x?0:"-.045em",lineHeight:x?1.3:.98,textWrap:"balance"},children:p}),s&&(0,i.jsx)("p",{className:"px-h-c",style:{margin:"18px 0 0",maxWidth:"46ch",fontSize:"clamp(15px,1.7vw,18px)",lineHeight:x?1.9:1.55,opacity:.74},children:s}),l]}),(0,i.jsx)("div",{"aria-hidden":"true",style:{position:"absolute",insetInline:0,bottom:0,height:6,opacity:.4,background:`repeating-linear-gradient(90deg, ${a} 0 16px, transparent 16px 40px)`}}),(0,i.jsx)("style",{children:`
        @keyframes px-pop { from { opacity: 0; transform: translateY(10px) scale(.7) } to { opacity: var(--op); transform: none } }
        @keyframes px-rise { from { opacity: 0; transform: translateY(14px) } to { opacity: 1; transform: none } }
        .px-h-a { animation: px-rise 560ms cubic-bezier(.16,1,.3,1) both }
        .px-h-b { animation: px-rise 620ms cubic-bezier(.16,1,.3,1) 70ms both }
        .px-h-c { animation: px-rise 680ms cubic-bezier(.16,1,.3,1) 140ms both }
        .px-orn { position: absolute; top: 92px; inset-inline-end: clamp(16px,4vw,60px); width: 210px; height: 200px; z-index: 1 }
        @media (max-width: 760px) { .px-orn { display: none } }
        @media (prefers-reduced-motion: reduce) {
          .px-h-a, .px-h-b, .px-h-c { animation: none }
          .px-orn span { animation: none; opacity: var(--op) }
        }
      `})]})},"Wrap",0,({children:e,style:o})=>(0,i.jsx)("div",{style:{maxWidth:1480,margin:"0 auto",padding:"0 clamp(20px,5vw,64px)",...o},children:e}),"inputStyle",0,{fontFamily:"inherit",fontSize:14,minHeight:46,padding:"12px 14px",background:"rgba(255,254,236,.05)",color:"#FFFEEC",border:"1px solid rgba(255,254,236,.22)",borderRadius:0,outline:"none"}])}]);